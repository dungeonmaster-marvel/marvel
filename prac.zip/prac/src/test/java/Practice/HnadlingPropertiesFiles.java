package Practice;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class HnadlingPropertiesFiles {

    public static void main (String [] args) throws IOException {
        Properties prop = new Properties();
        FileInputStream fis =new FileInputStream("E:\\projects\\prac\\src\\test\\java\\Practice\\data.properties");
        prop.load(fis);
        System.out.println(prop.getProperty("browser"));
        prop.setProperty("browser","Firefox");
        FileOutputStream fos =new FileOutputStream("E:\\projects\\prac\\src\\test\\java\\Practice\\data.properties");
       prop.store(fos,null);
    }
}
