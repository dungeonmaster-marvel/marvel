package fileHandling;

import java.io.*;


public class fileInput {
    public static void main (String args[]) throws IOException{
            //create  a file
        File myobj = new File("E:\\projects\\DizireAutomation-master\\data\\demo2.txt");
        if (myobj.createNewFile()) {
            System.out.println("File is created");
        }
        else {
            System.out.println("File already exists");
        }
         Writer w = new FileWriter(myobj);
        BufferedWriter b = new BufferedWriter(w);
        b.write("Helllo");
       // b.flush();
         b.close();

        Reader r = new FileReader(myobj);
        BufferedReader brr = new BufferedReader(r);
        String x = "";
        while((x = brr.readLine())!=null) {
            System.out.println(x);
            }
        }
    }

