package testNG;

public class ReportsLogging {
}
