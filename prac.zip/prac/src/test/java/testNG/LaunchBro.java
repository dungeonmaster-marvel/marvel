package testNG;

import org.testng.annotations.Test;

public class LaunchBro extends LaunchChrome {
    @Test
    public void LaunchAmazon() throws InterruptedException {
        driver.get("https://www.amazon.com");
        Thread.sleep(2000);
        System.out.println("Open Browser");
    }
}
