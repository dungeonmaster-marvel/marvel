package testNG;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class PracticeTesting extends LaunchChrome {

    @Test
    public void LaunchBrowser() throws InterruptedException {
        driver.get("https://www.amazon.com");
        Thread.sleep(2000);
        System.out.println("Open Browser111");
    }
}
