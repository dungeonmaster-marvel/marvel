package Collections;

import java.util.HashSet;

class Book{
    int  id,quantity;
    String author;
    String name;
Book(int id, int quantity, String author, String name){
this.id = id;
this.quantity = quantity;
this.author = author;
this.name = name;
    }
}

public class HashSetBook {
public static void main(String args[]){
    HashSet<Book> set = new HashSet<>();
    Book b1 = new Book(101,10,"Queen","ABC");
    Book b2 = new Book(120,20,"king","XYZ");
    set.add(b1);
    set.add(b2);
for(Book b:set){
    System.out.println(b.id+" "+b.quantity+" "+b.name+" "+b.author);
}
}
    }
