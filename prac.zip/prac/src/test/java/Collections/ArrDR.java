package Collections;

import java.util.ArrayList;

public class ArrDR {

    public static void main(String args[]){
        ArrayList<Object> list = new ArrayList<>();
    list.add("1");
    list.add("2");
    list.add("3");
    list.add("4");
    System.out.println("initial" +list);
    list.remove("3");
    System.out.println("Remove Object" +list);
    list.remove(1);
    System.out.println("Remove Index" +list);
    }
}
