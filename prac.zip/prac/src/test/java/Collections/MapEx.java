package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapEx {
public static void main(String args[]){
    Map map = new HashMap<>();
    map.put(1, "g");
    map.put(2,"k");
    map.put(3,"s");
    map.put(4,"b");

    Set set = map.entrySet();
    Iterator itr = set.iterator();
    while (itr.hasNext())
    {
        Map.Entry entr = (Map.Entry)itr.next();
        System.out.println(entr.getKey() +" "+entr.getValue());
    }
}
}
