package Collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListpr {
    public static void main(String args[]){

        LinkedList<Object> list = new LinkedList<>();
        list.add("1");
        list.add("2");
        list.add("3");

        Iterator<Object>  itr =  list.iterator();
        while (itr.hasNext())
        {
            System.out.println(itr.next());
        }
    }
}
