package Collections;

import java.util.HashSet;
import java.util.Iterator;


public class HashSetpr {
    public static void main(String args[]) {
        HashSet<String> set = new HashSet<>();
        set.add("One");
        set.add("two");
        Iterator<String> itr = set.iterator();
        while (itr.hasNext()){
             System.out.println(itr.next());
        }
    }
    }


