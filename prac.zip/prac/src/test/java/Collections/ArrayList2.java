package Collections;

import java.util.ArrayList;
import java.util.*;
public class ArrayList2 {

    public static void main(String args[]){
        ArrayList<Object> list = new ArrayList<>();
        list.add("ravii");
        list.add("hello");

        //Getting Iterator
        Iterator itr=list.iterator();

        while (itr.hasNext()){
                System.out.println(list);
        }
    }
}
