package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class foxBrowser {
    protected WebDriver driver;

    @BeforeClass
    public void openBrowser(){
        WebDriverManager.firefoxdriver().setup();
        driver= new FirefoxDriver();
    }
    @Test
    public void acessSite() throws InterruptedException {
        driver.get("https://www.google.com/");
        Thread.sleep(2000);
        System.out.println("open google");
    }
    @AfterClass
    public void closeBrowser(){
        driver.close();
    }

}
