package SeleniumPractice;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class RelativeXpath extends chromeLaunch{
    @Test
    public void relativePath(){
        driver.get("https://www.rediff.com/");
        System.out.println("Rediff Opened");
        driver.findElement(By.xpath("//*[@class='mailicon']")).click();
        driver.findElement(By.xpath("//*[@id='login1']")).sendKeys("gurucj");
        System.out.println("Username entered");
    }
}
