package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class chromeLaunch {
    protected WebDriver driver;

    @BeforeClass
    public void launchBrowser(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        System.out.println("Launch");
    }

    @AfterClass
    public void shutBrowser(){
        driver.close();
        System.out.println("Close");
    }
}
