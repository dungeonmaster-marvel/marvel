package SeleniumPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;

public class AttributeXpath extends chromeLaunch{

    @Test
    public void lunchGoogle(){
        driver.get("https://www.google.com/");
        driver.findElement(By.xpath("//*[@class='gLFyf gsfi'][@name='q']")).sendKeys("javatpoint", Keys.ENTER);

        System.out.println("entered");
        //driver.findElement(By.xpath("//*[@class='gNO89b']")).click();

       }


}
