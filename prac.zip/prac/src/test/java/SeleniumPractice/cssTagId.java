package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class cssTagId {

    protected WebDriver driver;

    @BeforeClass
    public void oceanSite(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        System.out.println("launch");
      }
    @Test
    public void blowerSite() throws InterruptedException {
       // driver.get(" https://www.testandquiz.com/selenium/testing.html");

        driver.get("https://www.google.com/");

        //css - Tagid
        //driver.findElement(By.cssSelector("button#dblClkBtn"));
        //css classname
        //driver.findElement(By.cssSelector("input.Automation")).click();
        //css class and attribute
        driver.findElement(By.cssSelector("input.gsfi[name=q]")).sendKeys("hello");
        Thread.sleep(2000);
        System.out.println("open");
    }
    @AfterClass
    public void oceanClose(){
        driver.close();
        System.out.println("Close browser");
    }
}
