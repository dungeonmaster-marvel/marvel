package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class byId {

    protected WebDriver driver;

    @BeforeClass
    public void chromeSetup()
    {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        System.out.println("Open Browser");
    }
    @Test
    public void sampleById() throws Exception{
        driver.get("https://www.testandquiz.com/selenium/testing.html");
        driver.findElement(By.id("fname")).sendKeys("JavaTpoint", Keys.ENTER);
       // driver.findElement(By.id("idOfButton")).click();
        System.out.println("Success");
        String actual = "Sample Test Page";
        Assert.assertEquals(driver.getTitle(),actual);
    }
    @AfterClass
    public void closeBrows(){
        driver.close();
        System.out.println("browser close");
    }
}
