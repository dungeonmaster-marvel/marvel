package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class byName {
    protected WebDriver driver;

    @BeforeClass
    public void browserOpen(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }
    @Test
    public void siteOpen() throws Exception {
        driver.get("https://www.testandquiz.com/selenium/testing.html");
        driver.findElement(By.name("firstName")).sendKeys("Text");
        Thread.sleep(2000);
        driver.findElement(By.id("idOfButton")).click();

       // String actual = "Make the most of your time at home with tips for recipes, workouts, and more";
      //  Assert.assertEquals("Make the most of your time at home with tips for recipes, workouts, and more", actual);

    }
    @AfterClass
    public void browserClose(){
        driver.close();
    }
}
