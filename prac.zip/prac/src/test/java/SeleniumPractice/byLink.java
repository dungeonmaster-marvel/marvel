package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class byLink {
    protected WebDriver driver;

    @BeforeClass
    public void brOpen(){

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        System.out.println("Open");
    }
    @Test
    public void siteeOpen(){
        driver.get("https://www.testandquiz.com/selenium/testing.html");
        driver.findElement(By.linkText("This is a link")).click();
        System.out.println("CLick on the link");
    }
    @AfterClass
    public void siteeClose(){
    driver.close();
    System.out.println("Close");
    }
}
