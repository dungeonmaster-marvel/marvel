package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class seleniumTpoing {

    protected WebDriver driver;

    @BeforeClass
    public void openBrowser(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        System.out.println("Open Browser");
    }
       @Test
    public void openSite() throws InterruptedException {
        driver.get("http://www.javatpoint.com");
        driver.manage().window().maximize();
        System.out.println("Open Javatpoint");
        Thread.sleep(2000);
        driver.navigate().to("https://www.primevideo.com/");
        System.out.println("Open Prime");

    }
    @AfterClass
    public void closeBrowser(){
        driver.close();
        System.out.println("Close Browser");
    }
}
//https://www.javatpoint.com/selenium-webdriver-locating-strategies