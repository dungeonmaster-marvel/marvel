package SeleniumPractice;

public class AlertsSelenium {


}
