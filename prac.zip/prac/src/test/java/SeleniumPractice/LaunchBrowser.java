package SeleniumPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LaunchBrowser {

    protected WebDriver driver;

    @BeforeClass
    public void openBrowser(){
        System.setProperty("webdriver.chrome.driver","D:\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
    }
    @Test
    public void demo() throws InterruptedException {
        driver.get("https://www.amazon.com");
        Thread.sleep(2000);
        System.out.println("open broweser amazon");

    }
    public void closeBrowser(){
        driver.close();
    }
}
