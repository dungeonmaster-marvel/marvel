package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class byClassName {
    protected WebDriver driver;

    @BeforeClass
    public void broOpen(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

        System.out.println("Open Browser");

    }
    @Test
    public void sitOpen() throws InterruptedException {
      driver.get("https://www.testandquiz.com/selenium/testing.html");
        System.out.println(driver.findElement(By.className("Automation")).getText());
        driver.findElement(By.className("Performance")).click();
        Thread.sleep(3000);

    }

    @AfterClass
    public void Close()
    {
      driver.close();
      System.out.println("close");
    }
}
