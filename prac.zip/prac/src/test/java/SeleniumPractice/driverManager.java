package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static java.lang.Thread.sleep;

public class driverManager {
    protected WebDriver driver;
    String browser = "firefox";

    @BeforeClass
    public void openBrowserm(){
        if (browser.equalsIgnoreCase("chrome"))
        {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
            }
    else if (browser.equalsIgnoreCase("firefox")){
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        }
    System.out.println("Open Browser");
    }
    @Test
    public void demo() throws InterruptedException{

        driver.get("https://www.amazon.com");
        Thread.sleep(2000);
        System.out.println("Amazon open");
    }
    @AfterClass
    public void close(){
        driver.close();
        System.out.println("Close browser");
    }
}
