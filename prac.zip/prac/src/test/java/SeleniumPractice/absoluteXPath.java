package SeleniumPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class absoluteXPath extends chromeLaunch {
      @Test
    public void newBrwose(){
        driver.get("https://www.testandquiz.com/selenium/testing.html");
        System.out.println("site open");
        //xpath absolute
       // driver.findElement(By.xpath("html/body/div[1]/div[4]/div[1]/p/a")).click();
        driver.findElement(By.xpath("html//body/div[1]/div[13]/div[1]/div[1]"));
        System.out.println("Clicked");
          //*[@class='mailicon']
    }
}
