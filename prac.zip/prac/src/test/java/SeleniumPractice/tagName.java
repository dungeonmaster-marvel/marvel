package SeleniumPractice;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

public class tagName {
    protected WebDriver driver;
    @BeforeClass
    public void opBrowser(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }
    @Test
    public void opSite(){
        driver.get("https://www.testandquiz.com/selenium/testing.html");
        driver.findElement(By.tagName("input")).sendKeys("hello");
        driver.findElement(By.tagName("button")).click();
        List<WebElement> button = driver.findElements(By.tagName("Button"));
        System.out.println("count of buttons"+ button.size());

    }
    @AfterClass
            public void closeSite2(){
        driver.close();
    }
}
