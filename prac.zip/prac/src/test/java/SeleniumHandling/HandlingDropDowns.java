package SeleniumHandling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class HandlingDropDowns extends LanchBrowser{

    @Test
    public void openSi(){
       driver.get("https://www.testandquiz.com/selenium/testing.html");
        Select dropdown = new Select (driver.findElement(By.id("testingDropdown")));
        dropdown.selectByValue("Database");

    }
}
