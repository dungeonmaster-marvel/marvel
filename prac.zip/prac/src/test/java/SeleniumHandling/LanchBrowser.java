package SeleniumHandling;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class LanchBrowser {
    protected WebDriver driver;

    @BeforeTest
    public void openBro(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        System.out.println("Open browser");
    }
    @AfterTest
    public void closeBro(){
        driver.close();
        System.out.println("Close Browser");
    }
}
