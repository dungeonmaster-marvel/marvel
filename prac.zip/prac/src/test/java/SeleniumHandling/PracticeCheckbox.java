package SeleniumHandling;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PracticeCheckbox extends LanchBrowser {

    @Test
            public void checkBoxes()

    {
       driver.get("https://rahulshettyacademy.com/AutomationPractice/"); //URL in the browser

        Assert.assertFalse(driver.findElement(By.id("checkBoxOption1")).isSelected());

//Assert.assertFalse(true);System.out.println(driver.findElement(By.cssSelector("input[id*='SeniorCitizenDiscount']")).isSelected());

        driver.findElement(By.id("checkBoxOption1")).click();

        System.out.println(driver.findElement(By.id("checkBoxOption1")).isSelected());

        Assert.assertTrue(driver.findElement(By.id("checkBoxOption1")).isSelected());
    }
}
