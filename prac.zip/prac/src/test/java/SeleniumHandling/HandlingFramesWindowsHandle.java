package SeleniumHandling;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.util.Iterator;
import java.util.Set;

public class HandlingFramesWindowsHandle extends LanchBrowser {

    @Test
    public void windowsSwitch(){
        driver.get("https://accounts.google.com/signup");
        driver.manage().window().maximize();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)");
        System.out.println(driver.getTitle());
        System.out.println("Before Switching");
        driver.findElement(By.xpath("//*[@href='https://support.google.com/accounts?hl=en-GB']")).click();
        driver.manage().window().maximize();
        Set<String> ids = driver.getWindowHandles();
        Iterator<String> it = ids.iterator();
        String parentId = it.next();
        String childId = it.next();
        driver.switchTo().window(childId);
        System.out.println(driver.getTitle());
        System.out.println("After Switching");
        //driver.quit();

        driver.switchTo().window(parentId);
        System.out.println(driver.getTitle());
        System.out.println("Switched back");

    }

    @Test
    public void framesWork() throws InterruptedException {
        driver.get("https://jqueryui.com/droppable/");
        System.out.println("Frame not entered");
        driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
        Actions a = new Actions(driver);
        WebElement source = driver.findElement(By.id("draggable"));
        WebElement destn  = driver.findElement(By.id("droppable"));

        a.dragAndDrop(source,destn).build().perform();
        Thread.sleep(2000);
        driver.switchTo().defaultContent();

    }

}
