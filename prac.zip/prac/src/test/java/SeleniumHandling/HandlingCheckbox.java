package SeleniumHandling;

import org.openqa.selenium.By;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.impl.HdrDocumentImpl;
import org.testng.annotations.Test;

public class HandlingCheckbox extends LanchBrowser{
    @Test
    public void openCheckbox(){
        driver.get("");
        driver.findElement(By.xpath("//*[@class='Performance']")).isSelected();
    }
}
