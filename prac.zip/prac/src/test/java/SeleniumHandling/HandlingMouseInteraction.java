package SeleniumHandling;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class HandlingMouseInteraction extends LanchBrowser {
    @Test
    public void mouseInteraction(){
        driver.get("https://www.amazon.com/");
        Actions act = new Actions(driver);
        act.moveToElement(driver.findElement(By.id("nav-link-accountList"))).build().perform();
        WebElement move = driver.findElement(By.name("field-keywords"));
        act.moveToElement(move).click().keyDown(Keys.SHIFT).sendKeys("hello");
       // act.moveToElement(move).
    }
}
