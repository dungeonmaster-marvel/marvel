package SeleniumHandling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class SpiceJet extends LanchBrowser {
    @Test
    public void spiceOpen() throws InterruptedException {
        driver.get(" https://www.spicejet.com/");
        //https://www.spicejet.com/
        //driver.findElement(By.cssSelector("input#ControlGroupSearchView_AvailabilitySearchInputSearchView_RoundTrip")).click();
       // WebElement testDropDown = driver.findElement(By.xpath("//*[@id='dropdownGroup1']/div/ul[1]/li[8]/a"));
        System.out.println("1");
        //Select dropdown = new Select(driver.findElement(By.xpath("//*[@id='dropdownGroup1']/div/ul[1]/li[8]/a")));
        //dropdown.selectByValue("BLR");
        //Passangers : Adult
        driver.findElement(By.id("divpaxinfo")).click();
        Thread.sleep(2000);
        System.out.println("2");

        /*Select s = new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult")));
       // s.selectByValue("2");
        s.selectByVisibleText("2");
        s.selectByIndex(1);*/

        //WebElement testDropDown2 = driver.findElement(By.xpath("//*[@value='IXG'][@text='Belagavi (IXG)']"));
        //Select downdrop = new Select(testDropDown2);*/

        Thread.sleep(2000);

    }
}
