package SeleniumHandling;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class DynamiDropDown extends LanchBrowser {
    @Test
    public void spiceOpen() throws InterruptedException {
        driver.get(" https://www.spicejet.com/");

        //driver.findElement(By.xpath("")).click();
        driver.findElement(By.xpath("//*[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
        //driver.findElement(By.cssSelector("input#ControlGroupSearchView_AvailabilitySearchInputSearchView_RoundTrip")).click();
        Thread.sleep(2000);
        System.out.println("0");
       /* driver.findElement(By.xpath("//*[@value='BLR']")).click();
        System.out.println("1");
        driver.findElement(By.xpath("(//*[@value='MAA'])[2]")).click();*/
    }
}
