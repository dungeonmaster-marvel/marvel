package SeleniumHandling;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class HandlingAlerts extends LanchBrowser{
    @Test
    public void openTest() throws InterruptedException{
        driver.get("https://mail.rediff.com/cgi-bin/login.cgi");
        System.out.println("opened");

        //driver.findElement(By.linkText("Generate Alert Box")).click();
          driver.findElement(By.xpath("//*[@name='proceed']")).click();

            Alert alert = (Alert)driver.switchTo().alert();
            Thread.sleep(2000);
            alert.accept();
             System.out.println("Alert Accepted");
     }
       /*  @Test
          public void testOpen(){
        driver.findElement(By.linkText("Generate Confirm Box")).click();

        Alert alt2 = driver.switchTo().alert();
        alt2.dismiss();

        System.out.println("Dismiss");
    }*/
}
