package SeleniumHandling;

import org.testng.annotations.Test;

public class MaximizeWindowDeleteCookie extends LanchBrowser{

    @Test
    public void maximizeDelete(){
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        //single Cookie
        driver.manage().deleteCookieNamed("xyz");

    }

}
