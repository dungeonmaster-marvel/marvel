package SeleniumHandling;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import testNG.LaunchChrome;

public class HandlingDragAndDrop extends LaunchChrome {

    private WebDriver dri;

    @Test
    public void opnBrowser() throws InterruptedException {
        driver.get("https://www.testandquiz.com/selenium/testing.html");
        WebElement to = driver.findElement(By.id("targetDiv"));
        WebElement from = driver.findElement(By.id("sourceImage"));

        Actions act = new Actions(driver);

        act.dragAndDrop(from,to).build().perform();

        //Thread.sleep(4000);
    }
}
