package SeleniumHandling;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.testng.annotations.Test;

public class HandlingRadioButtons extends LanchBrowser {
    @Test
    public void testRadio() throws InterruptedException {
        driver.get("https://www.testandquiz.com/selenium/testing.html");
        System.out.println(driver.getTitle());
        System.out.println(driver.getCurrentUrl());

        driver.findElement(By.xpath("//*[@id='female']")).click();
      // int a = driver.findElement(By.name("//*[@name='gender']")).size();
       //for (int i=1;i<a;i++){
       //    driver.findElement(By.xpath("//*[@name='gender']")).get(1).click();
       //}
        //Thread.sleep(2000);
    }
}
